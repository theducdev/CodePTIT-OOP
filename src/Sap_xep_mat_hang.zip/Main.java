import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        ArrayList<SanPham> ds = new ArrayList<>();
        Scanner scanner = new Scanner(new File("MATHANG.in"));
        int n = Integer.parseInt(scanner.nextLine());
        for (int i = 1; i <= n; i++){
            String ten = scanner.nextLine();
            String nhom = scanner.nextLine();
            float mua = Float.parseFloat(scanner.nextLine());
            float ban = Float.parseFloat(scanner.nextLine());
            SanPham x = new SanPham(i, ten, nhom, mua, ban);
            ds.add(x);
        }
        Collections.sort(ds, new Comparator<SanPham>() {
            @Override
            public int compare(SanPham o1, SanPham o2) {
                return (int)(o2.getLoinhuan() - o1.getLoinhuan());
            }
        });
        for(SanPham tmp : ds){
            System.out.println(tmp);
        }
    }
}
