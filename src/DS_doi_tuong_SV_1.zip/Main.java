import java.text.ParseException;
import java.util.*;

public class Main {
    public static void main(String[] args) throws ParseException {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        ArrayList <SinhVien1> ds = new ArrayList<>();
        for (int i = 1; i <= n; i++) {
            scanner.nextLine();
            SinhVien1 a = new SinhVien1(i, scanner.nextLine(), scanner.nextLine(), scanner.nextLine(), scanner.nextFloat());
            ds.add(a);
        }
        for (SinhVien1 x : ds) {
            System.out.println(x.toString());
        }
    }
}
