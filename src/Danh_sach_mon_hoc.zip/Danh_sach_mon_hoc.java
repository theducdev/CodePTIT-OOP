import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class Danh_sach_mon_hoc {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner scanner = new Scanner(new File("MONHOC.in"));
        int n = scanner.nextInt();
        scanner.nextLine();
        ArrayList <MonHoc> ds = new ArrayList<>();
        for (int i = 0; i < n; i++ ) {
            String ma = scanner.nextLine();
            String ten = scanner.nextLine();
            int tin = Integer.parseInt(scanner.nextLine());
            ds.add(new MonHoc(ma, ten, tin));

        }
        Collections.sort(ds, new Comparator<MonHoc>() {
            @Override
            public int compare(MonHoc o1, MonHoc o2) {
                return o1.getTen().compareTo(o2.getTen());
            }
        });
        for (MonHoc x : ds) {
            System.out.println(x);
        }
    }
}
