import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class Xep_hang {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        ArrayList <Pair<Integer, Integer>> ds = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            ds.add(new Pair<>(scanner.nextInt(), scanner.nextInt()));
        }
        Collections.sort(ds, new Comparator<Pair<Integer, Integer>>() {
            @Override
            public int compare(Pair<Integer, Integer> o1, Pair<Integer, Integer> o2) {
                return Integer.compare(o1.getA(), o2.getA());
            }
        });
        int sum = ds.get(0).getA();
        for (int i = 0; i < ds.size()-1; i++) {
            sum = Math.max(sum + ds.get(i).getB(),ds.get(i+1).getA());

        }
        System.out.println(sum + ds.get(ds.size()-1).getB());

    }
}
