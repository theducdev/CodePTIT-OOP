import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        ArrayList<Khach_hang> ds = new ArrayList<>();
        Scanner scanner = new Scanner(new File("KHACH.in"));
        int n = Integer.parseInt(scanner.nextLine());
        for (int i = 1; i <= n; i++){
            String ten = scanner.nextLine();
            String maphong = scanner.nextLine();
            String den = scanner.nextLine();
            String di = scanner.nextLine();
            Khach_hang x = new Khach_hang(i, ten, maphong, den, di);
            ds.add(x);
        }
        Collections.sort(ds, new Comparator<Khach_hang>() {
            @Override
            public int compare(Khach_hang o1, Khach_hang o2) {
                return o2.getLuutru().compareTo(o1.getLuutru());
            }
        });
        for(Khach_hang tmp : ds){
            System.out.println(tmp);
        }
    }
}
