import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Locale;

public class Khach_hang {
    String ma, ten, maphong;
    LocalDate den, di;
    Long luutru;

    public Khach_hang(int i, String ten, String maphong, String den, String di) {
        if (i < 10) {
            this.ma = "KH0" + i;
        }else {
            this.ma = "KH" + i;
        }
        this.ten = ten;
        this.maphong = maphong;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        this.den = LocalDate.parse(den, formatter);
        this.di = LocalDate.parse(di, formatter);
        this.luutru = ChronoUnit.DAYS.between(this.den, this.di);
    }

    public Long getLuutru() {
        return luutru;
    }

    @Override
    public String toString() {
        return ma + " " + ten + " " + maphong + " " + luutru;
    }

}
