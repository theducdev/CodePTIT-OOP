import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner scanner = new Scanner(new File("DN.in"));
        int n = scanner.nextInt();
        scanner.nextLine();
        ArrayList <DoanhNghiep> ds = new ArrayList<>();
        for (int i = 0; i < n; i++ ) {
            String ma = scanner.nextLine();
            String ten = scanner.nextLine();
            int tin = Integer.parseInt(scanner.nextLine());
            ds.add(new DoanhNghiep(ma, ten, tin));

        }
        Collections.sort(ds, new Comparator<DoanhNghiep>() {
            @Override
            public int compare(DoanhNghiep o1, DoanhNghiep o2) {
                return o1.getMa().compareTo(o2.getMa());
            }
        });
        for (DoanhNghiep x : ds) {
            System.out.println(x);
        }
    }
}
