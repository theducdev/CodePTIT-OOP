import java.text.*;
import java.util.*;

public class SinhVien {
    private String ma, ten, lop;
    private Date ns;
    private float gpa;

    public SinhVien (String ten, String lop, String ns, float gpa) throws ParseException{
        this.ma = "B20DCCN001";
        this.ten = ten;
        this.lop = lop;
        this.ns = new SimpleDateFormat("dd/MM/yyyy").parse(ns);
        this.gpa = gpa;

    }

    @Override
    public String toString() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String ngaySinhFormatted = dateFormat.format(ns);
        return ma + " " + ten + " " + lop + " " + ngaySinhFormatted + " " + String.format("%.2f", gpa);
    }

    public static void main(String[] args) throws ParseException {
        Scanner scanner = new Scanner(System.in);
        SinhVien a = new SinhVien(scanner.nextLine(),scanner.next(),scanner.next(),scanner.nextFloat());
        System.out.println(a.toString());

    }
}
