import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner scanner = new Scanner(new File("THISINH.in"));
        ArrayList <ThiSinh> ds =new ArrayList<>();
        int n = scanner.nextInt();
        scanner.nextLine();
        for (int i = 0; i < n; i++) {
            String ma = scanner.nextLine();
            String hoten = scanner.nextLine();
            Float toan = Float.parseFloat(scanner.nextLine());
            Float li = Float.parseFloat(scanner.nextLine());
            Float hoa = Float.parseFloat(scanner.nextLine());
            ThiSinh x = new ThiSinh(ma, hoten, toan, li, hoa);
            ds.add(x);
        }
        int chitieu = scanner.nextInt();
        if (chitieu > n) {
            chitieu=n;
        }
        Collections.sort(ds, new Comparator<ThiSinh>() {
            @Override
            public int compare(ThiSinh o1, ThiSinh o2) {
                if (o2.getTong()==o1.getTong()) {
                    return o1.getMa().compareTo(o2.getMa());
                }
                return (int) (o2.getTong()-o1.getTong());
            }
        });

        float diemchuan = ds.get(chitieu - 1).getTong();
        System.out.printf("%.1f\n", diemchuan);
        for (ThiSinh x : ds) {
            if (x.getTong() >= diemchuan) {
                x.setTt("TRUNG TUYEN") ;
            }else {
                x.setTt("TRUOT");
            }
        }

        for (ThiSinh x : ds) {
            System.out.println(x);
        }


    }


}
