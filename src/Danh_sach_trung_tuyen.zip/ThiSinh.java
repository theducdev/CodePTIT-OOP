public class ThiSinh {
    private String ma, hoten, tt;
    private float toan, li, hoa, uutien, tong;

    public ThiSinh(String ma, String hoten, float toan, float li, float hoa) {
        this.ma = ma;
        this.hoten = chuanHoaHoTen(hoten);
        this.toan = toan;
        this.li = li;
        this.hoa = hoa;
        if (ma.charAt(2)=='1') {
            this.uutien= 0.5F;
        }else if (ma.charAt(2) == '2') {
            this.uutien = 1;
        }else {
            this.uutien = 2.5F;
        }
        this.tong = toan*2 + li + hoa + this.uutien;
    }

    public void setTt(String tt) {
        this.tt = tt;
    }

    public String chuanHoaHoTen(String x) {
        String[] a = x.trim().split("\\s+");
        StringBuilder ans = new StringBuilder();
        for (String i : a) {
            ans.append(Character.toUpperCase(i.charAt(0))).append(i.substring(1).toLowerCase()).append(" ");
        }
        return String.valueOf(ans);
    }

    public String getMa() {
        return ma;
    }

    public float getTong() {
        return tong;
    }

    @Override
    public String toString() {
        String formattedUutien = uutien % 1 == 0 ? String.valueOf((int) uutien) : String.format("%.1f",uutien);
        String formattedTong = tong % 1 == 0 ? String.valueOf((int) tong) : String.format("%.1f",tong);
        return ma + " " + hoten + formattedUutien + " " + formattedTong + " " + tt;
    }
}
