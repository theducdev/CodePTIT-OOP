import java.io.IOException;

public class Liet_ke_tu_khac_nhau {
    public static void main(String[] args) throws IOException {
        WordSet ws = new WordSet("VANBAN.in");
        System.out.println(ws);
    }
}
