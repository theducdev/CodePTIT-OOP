import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.TreeSet;

public class WordSet {
    private TreeSet<String> a;

    public WordSet(String filePath) throws IOException {
        a = new TreeSet<>();
        addWordsFromFile(filePath);
    }

    public void addWordsFromFile(String filePath) throws IOException {
        this.a = new TreeSet<>();
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        String line;
        while((line = reader.readLine()) != null) {
            String[] lineWord = line.split("\\s+");
            for (String x : lineWord) {
                a.add(x.toLowerCase());
            }
        }
        reader.close();
    }


    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (String word : a) {
            sb.append(word).append("\n");
        }
        return sb.toString();
    }


}
