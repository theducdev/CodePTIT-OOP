import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException, ParseException {
        ArrayList<Khach_hang> ds = new ArrayList<>();
        Scanner scanner = new Scanner(new File("KHACHHANG.in"));
        int n = Integer.parseInt(scanner.nextLine());
        for (int i = 1; i <= n; i++){
            String ten = scanner.nextLine();
            String sophong = scanner.nextLine();
            String den = scanner.nextLine();
            String di = scanner.nextLine();
            long dichvu = Long.parseLong(scanner.nextLine());
            Khach_hang x = new Khach_hang(i, ten, sophong, den, di, dichvu);
            ds.add(x);
        }
        Collections.sort(ds, new Comparator<Khach_hang>() {
            @Override
            public int compare(Khach_hang o1, Khach_hang o2) {
                return (int)(o2.getTongtien() - o1.getTongtien());
            }
        });
        for(Khach_hang tmp : ds){
            System.out.println(tmp);
        }
    }
}
