public class Pair<T, U> {
    private int a;
    private int b;

    public Pair(int a, int b) {
        this.a = a;
        this.b = b;
    }

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    public boolean isPrime() {
        if (check_snt(a) && check_snt(b)) return true;
        return false;
    }

    public static boolean check_snt(int a) {
        if (a == 0 || a == 1) return false;
        for (int i = 2; i <= Math.sqrt(a); i++) {
            if (a % i == 0) return false;
        }
        return true;
    }

    public String toString() {
        return a + " " + b ;
    }
}
