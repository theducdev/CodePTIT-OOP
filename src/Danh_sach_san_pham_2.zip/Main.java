import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        ArrayList<SanPham> ds = new ArrayList<>();
        Scanner scanner = new Scanner(new File("SANPHAM.in"));
        int n = Integer.parseInt(scanner.nextLine());
        for (int i = 1; i <= n; i++){
            String ma = scanner.nextLine();
            String ten = scanner.nextLine();
            int gia = Integer.parseInt(scanner.nextLine());
            int bh = Integer.parseInt(scanner.nextLine());
            SanPham x = new SanPham(ma, ten, gia, bh);
            ds.add(x);
        }
        Collections.sort(ds, new Comparator<SanPham>() {
            @Override
            public int compare(SanPham o1, SanPham o2) {
                if (o1.getGia() == o2.getGia()) {
                    return o1.getMa().compareTo(o2.getMa());
                }
                return o2.getGia() - o1.getGia();
            }
        });
        for(SanPham tmp : ds){
            System.out.println(tmp);
        }
    }
}
