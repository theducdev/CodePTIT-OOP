import java.text.ParseException;
import java.util.*;

public class Main {
    public static void main(String[] args) throws ParseException {
        Scanner scanner = new Scanner(System.in);
        double width = scanner.nextInt();
        double height = scanner.nextInt();
        String color = scanner.next();
        if (width <= 0 || height <= 0) {
            System.out.println("INVALID");
        }else{
            Rectange x = new Rectange(width, height, color);
            String color1 = "";
            color1+=color.substring(0,1).toUpperCase();
            color1+=color.substring(1, color.length()).toLowerCase();
            System.out.print((int)x.findPerimeter() + " " + (int) x.findArea() +" " + color1);

        }

    }
}
